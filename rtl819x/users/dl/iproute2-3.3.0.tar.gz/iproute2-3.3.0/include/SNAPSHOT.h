static const char SNAPSHOT[] = "120319";
